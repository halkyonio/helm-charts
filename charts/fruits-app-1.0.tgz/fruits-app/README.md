# fruits-app

## Configuration

The following table lists the configurable parameters and their default values.

| Parameter | Description | Default |
|  ---  |  ---  |  ---  |
| `app.envs.DB_SERVICE_NAME` |   | fruits-app-db |
| `app.host` | The host under which the application is going to be exposed. | atomic-fruits.127.0.0.1.nip.io |
| `app.image` | The container image to use. | docker.io/runner/atomic-fruits:1.0-SNAPSHOT |
| `app.ports.http` | The http port to use for the probe. | 8080 |
| `app.serviceBinding.enabled` | Determine if the resource should be installed or not. | true |
| `db.auth.database` |   | fruits_database |
| `db.auth.password` |   | pwd |
| `db.auth.username` |   | user |
| `db.enabled` | Flag to enable/disable the dependency 'postgresql' | true |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.
Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart. For example,
```
$ helm install --name chart-name -f values.yaml .
```
> **Tip**: You can use the default [values.yaml](values.yaml)
